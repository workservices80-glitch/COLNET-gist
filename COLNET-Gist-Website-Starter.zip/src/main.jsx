import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, Bell, Bookmark, Check, ChevronDown, CircleHelp, Compass, Flame,
  Heart, Home, ImagePlus, LogIn, LogOut, Menu, MessageCircle, MoreHorizontal,
  Plus, Search, Send, ShieldCheck, ShoppingBag, SlidersHorizontal, Sparkles,
  ThumbsUp, UserRound, Users, X, MapPin, AlertTriangle, GraduationCap
} from "lucide-react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDocs, onSnapshot, orderBy, query,
  serverTimestamp, setDoc, updateDoc, where, limit
} from "firebase/firestore";
import { auth, db, firebaseReady } from "./firebase";
import "./styles.css";

const DEPARTMENTS = [
  "All departments", "Computer Science", "French", "English", "Mathematics",
  "Biology", "Chemistry", "Physics", "Business Education", "Educational Management",
  "Guidance and Counselling", "Social Studies", "Political Science", "Other"
];
const CATEGORIES = ["Campus gist", "Academic", "Department", "Lost & found", "Marketplace", "Question"];
const DEMO_POSTS = [
  { id:"demo1", author:"COLNET Campus Desk", department:"Campus Updates", category:"Campus gist", body:"Welcome to COLNET Gist 🌿 Your campus community starts here. Share useful updates, ask questions, and keep it respectful. What is happening around campus today?", createdAt:Date.now()-1000*60*18, likes:12, comments:3, anonymous:false, demo:true },
  { id:"demo2", author:"Anonymous student", department:"Computer Science", category:"Question", body:"What resources have helped you most with programming practicals this semester? Drop suggestions for everyone in the department.", createdAt:Date.now()-1000*60*60*3, likes:8, comments:5, anonymous:true, demo:true },
  { id:"demo3", author:"Campus Community", department:"Campus Updates", category:"Lost & found", body:"Found something on campus? Use the Lost & found category to help reunite items with their owners. Keep identifying details private and arrange handovers in a safe public place.", createdAt:Date.now()-1000*60*60*8, likes:6, comments:1, anonymous:false, demo:true },
];
const timeAgo = (value) => {
  const ms = typeof value === "number" ? value : value?.toMillis?.() || Date.now();
  const mins = Math.max(1, Math.floor((Date.now()-ms)/60000));
  if (mins < 60) return `${mins}m ago`;
  if (mins < 1440) return `${Math.floor(mins/60)}h ago`;
  return `${Math.floor(mins/1440)}d ago`;
};
const initials = (name="Student") => name.split(/\s+/).slice(0,2).map(s=>s[0]).join("").toUpperCase();

function App() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(!firebaseReady);
  const [posts, setPosts] = useState(DEMO_POSTS);
  const [likes, setLikes] = useState({});
  const [comments, setComments] = useState({});
  const [section, setSection] = useState("For you");
  const [department, setDepartment] = useState("All departments");
  const [category, setCategory] = useState("All posts");
  const [sort, setSort] = useState("Recent");
  const [search, setSearch] = useState("");
  const [showComposer, setShowComposer] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [toast, setToast] = useState("");
  const [bookmarks, setBookmarks] = useState([]);
  const [showComments, setShowComments] = useState({});
  const [adminPanel, setAdminPanel] = useState(false);

  const adminEmail = import.meta.env.VITE_ADMIN_EMAIL || "";
  const isAdmin = !!user && !!adminEmail && user.email?.toLowerCase() === adminEmail.toLowerCase();

  useEffect(() => {
    if (!firebaseReady) return;
    const unsub = onAuthStateChanged(auth, u => { setUser(u); setAuthReady(true); });
    return unsub;
  }, []);

  useEffect(() => {
    if (!firebaseReady) return;
    const q = query(collection(db, "posts"), orderBy("createdAt", "desc"), limit(100));
    return onSnapshot(q, snap => {
      const loaded = snap.docs.map(d => ({ id:d.id, ...d.data(), createdAt:d.data().createdAt?.toMillis?.() || Date.now() }));
      setPosts(loaded);
    }, () => setToast("Couldn't load posts. Check your Firestore setup and rules."));
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  const filteredPosts = useMemo(() => {
    let result = [...posts];
    if (section === "Trending") result.sort((a,b) => ((b.likeCount||b.likes||0)+(b.commentCount||b.comments||0)*2) - ((a.likeCount||a.likes||0)+(a.commentCount||a.comments||0)*2));
    else result.sort((a,b) => (b.createdAt||0)-(a.createdAt||0));
    if (department !== "All departments") result = result.filter(p => p.department === department);
    if (category !== "All posts") result = result.filter(p => p.category === category);
    if (section === "Saved") result = result.filter(p => bookmarks.includes(p.id));
    if (section === "Lost & found") result = result.filter(p => p.category === "Lost & found");
    if (section === "Marketplace") result = result.filter(p => p.category === "Marketplace");
    if (section === "My department" && user) result = result.filter(p => p.department === (user.department || department));
    if (search.trim()) {
      const s = search.toLowerCase();
      result = result.filter(p => `${p.body} ${p.author} ${p.department} ${p.category}`.toLowerCase().includes(s));
    }
    return result;
  }, [posts, section, department, category, search, bookmarks, user]);

  async function createPost(payload) {
    if (!user) { setShowAuth(true); setToast("Create an account or log in to publish a post."); return; }
    const post = {
      ...payload, author: payload.anonymous ? "Anonymous student" : (user.displayName || user.email.split("@")[0]),
      uid:user.uid, department: payload.department || user.department || "Other",
      createdAt: serverTimestamp(), likeCount:0, commentCount:0, status:"visible",
    };
    try {
      if (firebaseReady) await addDoc(collection(db,"posts"), post);
      else setPosts(p => [{...post,id:`local-${Date.now()}`,createdAt:Date.now(),likes:0,comments:0,demo:false},...p]);
      setShowComposer(false); setToast("Your post is live!");
    } catch { setToast("Couldn't publish. Check your Firebase configuration and security rules."); }
  }

  async function toggleLike(post) {
    if (!user) { setShowAuth(true); setToast("Log in to react to posts."); return; }
    const key = `${post.id}_${user.uid}`;
    const active = !!likes[key];
    setLikes(old => ({...old,[key]:!active}));
    if (firebaseReady && !post.demo) {
      const likeRef = doc(db,"posts",post.id,"likes",user.uid);
      try {
        if (active) await deleteDoc(likeRef); else await setDoc(likeRef,{uid:user.uid,createdAt:serverTimestamp()});
        await updateDoc(doc(db,"posts",post.id), { likeCount: Math.max(0,(post.likeCount||0)+(active?-1:1)) });
      } catch { setToast("Couldn't save reaction. Please try again."); setLikes(old=>({...old,[key]:active})); }
    } else {
      setPosts(old=>old.map(p=>p.id===post.id?{...p,likes:Math.max(0,(p.likes||0)+(active?-1:1))}:p));
    }
  }

  async function addComment(post, body) {
    if (!user) { setShowAuth(true); setToast("Log in to comment."); return; }
    try {
      if (firebaseReady && !post.demo) {
        await addDoc(collection(db,"posts",post.id,"comments"), {
          body, uid:user.uid, author:user.displayName || user.email.split("@")[0],
          createdAt:serverTimestamp()
        });
        await updateDoc(doc(db,"posts",post.id),{commentCount:(post.commentCount||0)+1});
      } else {
        setComments(old=>({...old,[post.id]:[...(old[post.id]||[]),{body,author:user.displayName||"You",createdAt:Date.now()}]}));
        setPosts(old=>old.map(p=>p.id===post.id?{...p,comments:(p.comments||0)+1}:p));
      }
      setToast("Comment added.");
    } catch { setToast("Couldn't add comment."); }
  }

  async function removePost(post) {
    if (!isAdmin) return;
    if (!confirm("Remove this post from the community feed?")) return;
    try {
      if (firebaseReady && !post.demo) await updateDoc(doc(db,"posts",post.id),{status:"removed"});
      setPosts(old=>old.filter(p=>p.id!==post.id)); setToast("Post removed.");
    } catch { setToast("Could not remove this post."); }
  }

  async function handleSignOut() {
    if (firebaseReady) await signOut(auth);
    setUser(null); setToast("You are logged out.");
  }

  const navItems = [
    {name:"For you",icon:Home},{name:"Trending",icon:Flame},{name:"My department",icon:GraduationCap},
    {name:"Lost & found",icon:Search},{name:"Marketplace",icon:ShoppingBag},{name:"Saved",icon:Bookmark}
  ];

  return <div className="app-shell">
    <header className="topbar">
      <button className="icon-button mobile-only" aria-label="Open menu" onClick={()=>setMobileMenu(!mobileMenu)}><Menu size={21}/></button>
      <a className="brand" href="#" onClick={e=>{e.preventDefault();setSection("For you")}}>
        <span className="brand-mark"><Sparkles size={21}/></span><span><strong>COLNET <em>Gist</em></strong><small>FCE ABEOKUTA COMMUNITY</small></span>
      </a>
      <div className="top-search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search campus gist..." aria-label="Search posts"/><kbd>⌘ K</kbd></div>
      <div className="top-actions">
        <button className="icon-button notification" title="Notifications" onClick={()=>setToast("You're all caught up!") }><Bell size={19}/><i/></button>
        {user ? <button className="user-chip" onClick={handleSignOut}><span className="avatar small">{initials(user.displayName||user.email)}</span><span className="user-chip-name">{user.displayName||"Student"}</span><LogOut size={15}/></button> :
          <button className="button button-dark sign-in" onClick={()=>{setAuthMode("login");setShowAuth(true)}}><LogIn size={16}/> Log in</button>}
      </div>
    </header>

    <div className="layout">
      <aside className={`sidebar ${mobileMenu?"sidebar-open":""}`}>
        <div className="side-label">YOUR CAMPUS</div>
        <nav>{navItems.map(({name,icon:Icon})=><button key={name} className={`nav-link ${section===name?"active":""}`} onClick={()=>{setSection(name);setMobileMenu(false)}}><Icon size={19}/><span>{name}</span>{name==="Trending"&&<span className="hot-dot"/>}</button>)}</nav>
        <div className="side-rule"/>
        <div className="side-label">QUICK SPACES</div>
        <button className="nav-link" onClick={()=>{setCategory("Department");setSection("For you")}}><Users size={19}/><span>Department talk</span></button>
        <button className="nav-link" onClick={()=>{setCategory("Question");setSection("For you")}}><MessageCircle size={19}/><span>Ask the campus</span></button>
        <button className="nav-link" onClick={()=>{setCategory("Academic");setSection("For you")}}><GraduationCap size={19}/><span>Academic corner</span></button>
        {isAdmin&&<><div className="side-rule"/><button className="nav-link admin-link" onClick={()=>setAdminPanel(!adminPanel)}><ShieldCheck size={19}/><span>Admin moderation</span></button></>}
        <div className="sidebar-card">
          <div className="sidebar-card-icon"><Compass size={19}/></div><strong>Campus is better<br/>when we connect.</strong><p>Share stories. Find your people. Keep it respectful.</p>
          <button onClick={()=>setShowComposer(true)}>Create a post <Plus size={15}/></button>
        </div>
        <div className="sidebar-foot"><span className="status-dot"/> Community guidelines <span>·</span> Privacy first</div>
      </aside>

      <main className="feed">
        <section className="welcome-banner">
          <div className="banner-copy"><div className="eyebrow"><span/> THE CAMPUS CONVERSATION</div><h1>Your campus.<br/><span>Your stories.</span></h1><p>The gist, the updates, the people — all in one place.</p><button className="button button-lime" onClick={()=>user?setShowComposer(true):(setShowAuth(true))}>Start a conversation <Send size={16}/></button></div>
          <div className="banner-art" aria-hidden="true"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="art-circle"><Users size={54}/></div><span className="float-pill pill-one"><Heart size={15} fill="currentColor"/> good vibes</span><span className="float-pill pill-two"><MessageCircle size={15}/> campus gist</span><span className="sparkle s1">✳</span><span className="sparkle s2">✦</span></div>
        </section>

        <div className="feed-heading"><div><div className="section-kicker">COMMUNITY FEED</div><h2>{section==="For you"?"What’s happening":section}</h2><p>Real conversations from the FCE Abeokuta community.</p></div><button className="button button-outline desktop-create" onClick={()=>user?setShowComposer(true):setShowAuth(true)}><Plus size={17}/> Create post</button></div>

        <div className="filter-row">
          <div className="feed-tabs"><button className={sort==="Recent"?"selected":""} onClick={()=>setSort("Recent")}>Latest</button><button className={sort==="Popular"?"selected":""} onClick={()=>{setSort("Popular");setSection("Trending")}}><Flame size={15}/> Popular</button></div>
          <label className="select-wrap"><SlidersHorizontal size={15}/><select value={department} onChange={e=>setDepartment(e.target.value)} aria-label="Filter by department">{DEPARTMENTS.map(d=><option key={d}>{d}</option>)}</select><ChevronDown size={14}/></label>
          <label className="select-wrap category-select"><select value={category} onChange={e=>setCategory(e.target.value)} aria-label="Filter by category"><option>All posts</option>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select><ChevronDown size={14}/></label>
        </div>

        {section==="Marketplace"&&<div className="notice-strip"><ShoppingBag size={17}/><span><strong>Campus marketplace</strong> — list books, supplies, and student services. Meet in a public campus location.</span></div>}
        {section==="Lost & found"&&<div className="notice-strip"><Search size={17}/><span><strong>Lost something?</strong> Post a description, but keep private identifying details out of public posts.</span></div>}
        {adminPanel&&isAdmin&&<div className="admin-panel"><div><ShieldCheck size={19}/><strong>Admin moderation</strong></div><p>Review reported content, remove harmful posts, and apply community rules. Report queues can be connected through the Firestore reports collection.</p><button className="button button-outline" onClick={()=>setToast("Admin view is active. Use the menu on each post to remove it.")}>Got it</button></div>}

        {!firebaseReady&&<div className="demo-note"><CircleHelp size={17}/><span><strong>Preview mode</strong> — these sample posts are for the design preview. Connect Firebase to enable real accounts, shared posts, and cross-device data.</span></div>}

        <div className="posts-list">
          {filteredPosts.length===0?<div className="empty-state"><div><Search size={26}/></div><h3>No posts found</h3><p>Try another filter or be the first to start a conversation.</p><button className="button button-dark" onClick={()=>user?setShowComposer(true):setShowAuth(true)}>Create a post</button></div>:
            filteredPosts.map(post=><PostCard key={post.id} post={post} user={user} liked={!!likes[`${post.id}_${user?.uid}`]} bookmarked={bookmarks.includes(post.id)} onLike={()=>toggleLike(post)} onBookmark={()=>setBookmarks(old=>old.includes(post.id)?old.filter(x=>x!==post.id):[...old,post.id])} onComment={body=>addComment(post,body)} comments={comments[post.id]||[]} showComments={!!showComments[post.id]} toggleComments={()=>setShowComments(old=>({...old,[post.id]:!old[post.id]}))} isAdmin={isAdmin} onRemove={()=>removePost(post)} onReport={()=>{if(!user){setShowAuth(true);return;}setToast("Thanks. Reporting workflow needs the Firebase reports collection enabled.")}}/>)}
        </div>
        <footer className="feed-footer">Made for the FCE Abeokuta community <span>✳</span> Be kind. Be campus-smart.</footer>
      </main>

      <aside className="rightbar">
        <div className="right-card community-card"><div className="card-topline"><span className="right-card-kicker">CAMPUS COMMUNITY</span><span className="live-tag"><i/> LIVE</span></div><h3>Good gist travels.<br/>Respect matters.</h3><p>Help make this a welcoming space for every student.</p><div className="community-stats"><div><strong>{posts.length}</strong><span>Posts shown</span></div><div><strong>{DEPARTMENTS.length-1}</strong><span>Study areas</span></div></div><button className="text-link" onClick={()=>setToast("Guidelines: be respectful, don't share private details, and report harmful content.")}>Read community guidelines <span>↗</span></button></div>
        <div className="right-card trends-card"><div className="right-card-head"><h3><Flame size={17}/> Trending topics</h3><button title="Refresh trends" onClick={()=>setSection("Trending")}><Activity size={16}/></button></div>{[["#FCEAbeokuta","Campus life"],["#StudyTips","Academics"],["#DepartmentGist","Department talk"],["#LostAndFound","Lost & found"]].map(([tag,desc],i)=><button className="trend-item" key={tag} onClick={()=>{setSearch(tag.replace("#",""));setSection(i===3?"Lost & found":"Trending")}}><span className="trend-rank">0{i+1}</span><span><strong>{tag}</strong><small>{desc}</small></span><MoreHorizontal size={17}/></button>)}</div>
        <div className="right-card safety-card"><div className="safety-icon"><ShieldCheck size={19}/></div><div><strong>Keep it safe</strong><p>Never post passwords, student IDs, phone numbers, or private information about someone else.</p></div></div>
        <div className="right-links"><button onClick={()=>setToast("Community guidelines: respect others, verify information, protect privacy.")}>Guidelines</button><button onClick={()=>setToast("Contact your COLNET Gist administrator to report a safety issue.")}>Contact</button><span>© 2026 COLNET Gist</span></div>
      </aside>
    </div>

    {showComposer&&<Composer user={user} onClose={()=>setShowComposer(false)} onSubmit={createPost}/>}
    {showAuth&&<AuthModal mode={authMode} setMode={setAuthMode} onClose={()=>setShowAuth(false)} onSuccess={u=>{setUser(u);setShowAuth(false);setToast("Welcome to COLNET Gist!");}}/>}
    {toast&&<div className="toast" role="status"><Check size={17}/>{toast}<button onClick={()=>setToast("")} aria-label="Dismiss"><X size={15}/></button></div>}
  </div>;
}

function PostCard({post,user,liked,bookmarked,onLike,onBookmark,onComment,comments,showComments,toggleComments,isAdmin,onRemove,onReport}) {
  const [commentText,setCommentText] = useState("");
  const [menu,setMenu] = useState(false);
  const author = post.anonymous ? "Anonymous student" : (post.author||"FCE student");
  const countLikes = post.likeCount ?? post.likes ?? 0;
  const countComments = post.commentCount ?? post.comments ?? comments.length;
  return <article className="post-card">
    <div className="post-top"><div className={`avatar ${post.anonymous?"anonymous":""}`}>{post.anonymous?<UserRound size={19}/>:initials(author)}</div><div className="post-author"><div><strong>{author}</strong>{post.uid===user?.uid&&<span className="you-tag">YOU</span>}</div><span>{post.department||"Campus community"} <i>·</i> {timeAgo(post.createdAt)}</span></div><div className="post-menu-wrap"><button className="icon-button post-menu-btn" aria-label="Post options" onClick={()=>setMenu(!menu)}><MoreHorizontal size={20}/></button>{menu&&<div className="post-menu"><button onClick={()=>{onBookmark();setMenu(false)}}><Bookmark size={15}/>{bookmarked?"Remove saved":"Save post"}</button><button onClick={()=>{onReport();setMenu(false)}}><AlertTriangle size={15}/>Report post</button>{isAdmin&&<button className="danger" onClick={()=>{onRemove();setMenu(false)}}><X size={15}/>Remove post</button>}</div>}</div></div>
    <div className="post-category-row"><span className={`category-pill ${post.category==="Lost & found"?"lost":post.category==="Marketplace"?"market":""}`}>{post.category||"Campus gist"}</span>{post.anonymous&&<span className="anon-label"><UserRound size={12}/> Anonymous</span>}</div>
    <p className="post-body">{post.body}</p>
    {post.imageUrl&&<img className="post-image" src={post.imageUrl} alt="Post attachment"/>}
    <div className="post-metrics"><span>{countLikes} reactions</span><button onClick={toggleComments}>{countComments} comments</button></div>
    <div className="post-actions"><button className={liked?"reacted":""} onClick={onLike}><Heart size={18} fill={liked?"currentColor":"none"}/><span>Like</span></button><button onClick={toggleComments}><MessageCircle size={18}/><span>Comment</span></button><button className={bookmarked?"reacted":""} onClick={onBookmark}><Bookmark size={17} fill={bookmarked?"currentColor":"none"}/><span>Save</span></button></div>
    {showComments&&<div className="comments-area">{comments.map((c,i)=><div className="comment" key={i}><span className="avatar mini">{initials(c.author||"Student")}</span><div><strong>{c.author||"Student"}</strong><p>{c.body}</p></div></div>)}<form className="comment-form" onSubmit={e=>{e.preventDefault();if(commentText.trim()){onComment(commentText.trim());setCommentText("");}}}><input value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder={user?"Write a respectful comment...":"Log in to comment"} disabled={!user}/><button type="submit" disabled={!user||!commentText.trim()} aria-label="Send comment"><Send size={17}/></button></form></div>}
  </article>;
}

function Composer({user,onClose,onSubmit}) {
  const [body,setBody]=useState("");
  const [category,setCategory]=useState("Campus gist");
  const [department,setDepartment]=useState(user?.department||"Other");
  const [anonymous,setAnonymous]=useState(false);
  const [imageUrl,setImageUrl]=useState("");
  const [error,setError]=useState("");
  function submit(e){e.preventDefault();if(body.trim().length<8){setError("Write at least 8 characters so people understand your post.");return;}if(body.length>1500){setError("Please keep posts under 1,500 characters.");return;}onSubmit({body:body.trim(),category,department,anonymous,imageUrl:imageUrl.trim()||""});}
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><section className="modal composer-modal"><div className="modal-header"><div><span className="section-kicker">YOUR VOICE MATTERS</span><h2>Create a post</h2></div><button className="icon-button" onClick={onClose}><X size={20}/></button></div><form onSubmit={submit}><label className="field-label">What's the gist?</label><textarea autoFocus value={body} onChange={e=>setBody(e.target.value)} placeholder="Share a campus update, ask a question, or start a conversation..." rows={5}/><div className="character-count">{body.length}/1500</div><div className="form-grid"><label><span className="field-label">Category</span><select value={category} onChange={e=>setCategory(e.target.value)}>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></label><label><span className="field-label">Department / space</span><select value={department} onChange={e=>setDepartment(e.target.value)}>{DEPARTMENTS.filter(d=>d!=="All departments").map(d=><option key={d}>{d}</option>)}</select></label></div><label className="field-label image-label">Image URL (optional)<input value={imageUrl} onChange={e=>setImageUrl(e.target.value)} placeholder="https://example.com/image.jpg"/></label><label className="anonymous-toggle"><input type="checkbox" checked={anonymous} onChange={e=>setAnonymous(e.target.checked)}/><span className="toggle-box"><Check size={13}/></span><span><strong>Post anonymously</strong><small>Your public name will be hidden. Moderators may still need account records to investigate abuse.</small></span></label>{error&&<p className="form-error">{error}</p>}<div className="modal-footer"><span><ShieldCheck size={16}/> Keep it kind and safe.</span><button className="button button-dark" type="submit">Publish post <Send size={15}/></button></div></form></section></div>;
}

function AuthModal({mode,setMode,onClose,onSuccess}) {
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [name,setName]=useState("");
  const [department,setDepartment]=useState("Computer Science");
  const [error,setError]=useState("");
  const [busy,setBusy]=useState(false);
  async function submit(e) {
    e.preventDefault();setError("");
    if(!firebaseReady){setError("Firebase isn't connected yet. Follow README.md to configure your project, then restart the app.");return;}
    if(password.length<6){setError("Password must be at least 6 characters.");return;}
    setBusy(true);
    try {
      let cred;
      if(mode==="signup"){
        if(!name.trim()){setError("Please enter your display name.");setBusy(false);return;}
        cred=await createUserWithEmailAndPassword(auth,email.trim(),password);
        await updateProfile(cred.user,{displayName:name.trim()});
        await setDoc(doc(db,"users",cred.user.uid),{uid:cred.user.uid,displayName:name.trim(),email:email.trim(),department,role:"student",createdAt:serverTimestamp()});
        onSuccess({...cred.user,displayName:name.trim(),department});
      } else {
        cred=await signInWithEmailAndPassword(auth,email.trim(),password);
        onSuccess(cred.user);
      }
    } catch(err) {
      const messages={"auth/email-already-in-use":"That email already has an account.","auth/invalid-email":"Enter a valid email address.","auth/invalid-credential":"Email or password is incorrect.","auth/weak-password":"Choose a stronger password.","auth/too-many-requests":"Too many attempts. Please try again later."};
      setError(messages[err.code]||err.message||"Couldn't authenticate. Check your Firebase setup.");
    } finally {setBusy(false);}
  }
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><section className="modal auth-modal"><div className="auth-brand"><span className="brand-mark"><Sparkles size={22}/></span><span><strong>COLNET <em>Gist</em></strong><small>FCE ABEOKUTA COMMUNITY</small></span><button className="icon-button close-auth" onClick={onClose}><X size={20}/></button></div><div className="auth-intro"><h2>{mode==="signup"?"Join the conversation.":"Welcome back."}</h2><p>{mode==="signup"?"Create your student community account to post, react, and connect.":"Log in to catch up with your campus community."}</p></div><form onSubmit={submit}>{mode==="signup"&&<><label className="field-label">Display name</label><input className="text-field" value={name} onChange={e=>setName(e.target.value)} placeholder="What should students call you?" required/><label className="field-label">Department</label><select className="text-field" value={department} onChange={e=>setDepartment(e.target.value)}>{DEPARTMENTS.filter(d=>d!=="All departments").map(d=><option key={d}>{d}</option>)}</select></>}<label className="field-label">Email address</label><input className="text-field" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required/><label className="field-label">Password</label><input className="text-field" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} required/>{error&&<p className="form-error">{error}</p>}<button className="button button-dark auth-submit" disabled={busy}>{busy?"Please wait...":mode==="signup"?"Create my account":"Log in"} <Send size={16}/></button></form><p className="auth-switch">{mode==="signup"?"Already part of the community?":"New to COLNET Gist?"} <button onClick={()=>{setError("");setMode(mode==="signup"?"login":"signup")}}>{mode==="signup"?"Log in":"Create an account"}</button></p><p className="auth-terms">By continuing, you agree to keep the community respectful and protect other students' privacy.</p></section></div>;
}

createRoot(document.getElementById("root")).render(<React.StrictMode><App/></React.StrictMode>);
