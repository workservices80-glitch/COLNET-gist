# COLNET Gist — FCE Abeokuta

A responsive React + Vite community feed starter for FCE Abeokuta students. It includes a polished mobile-first interface, Firebase email/password authentication, shared Firestore posts, reactions, comments, anonymous posting, department/category filters, trending feed, saved posts, lost-and-found, marketplace categories, and a starter admin moderation view.

## Important status

This is a deployable starter, **not a live deployed website yet**. To make accounts and posts genuinely shared across devices, you must connect a Firebase project and deploy the app. In preview mode, sample posts are shown and new posts are only local to that browser session. Private messaging is represented in the product plan but is not yet implemented as a usable chat interface; the Firestore rules include a starting point only. Admin reporting needs its report-write workflow and secure role setup before production.

## 1. Prerequisites

Install Node.js 20 or newer. Create accounts on Firebase and GitHub (or use another static host).

## 2. Create and configure Firebase

1. Open https://console.firebase.google.com/ and create a project named `colnet-gist-fce`.
2. Add a **Web app** and copy the Firebase configuration.
3. In **Authentication → Sign-in method**, enable **Email/Password**.
4. In **Firestore Database**, create a database (choose a region close to your users, such as a suitable region in Europe if available).
5. In the project root, copy `.env.example` to `.env` and fill in the Web app values. The values are public client config, not admin credentials. Never put a service-account private key in this app.
6. Set `VITE_ADMIN_EMAIL` to the exact email address you will use as admin.
7. Edit `firestore.rules` and replace `admin@example.com` with that exact admin email, then publish the rules in Firebase Console → Firestore Database → Rules.
8. Restart the development server after changing `.env`.

For a production community, prefer Firebase custom claims for admin privileges instead of an email-only role check. Do not use broad public write rules.

## 3. Run locally

```bash
npm install
cp .env.example .env
# Edit .env with your Firebase values
npm run dev
```

Open the local URL Vite prints. On Windows, copy `.env.example` to `.env` manually if `cp` is unavailable.

## 4. Build and deploy

### Netlify (easy option)
1. Push this folder to a new GitHub repository.
2. In https://app.netlify.com/ choose **Add new site → Import an existing project**.
3. Select the repository. Build command: `npm run build`; publish directory: `dist`.
4. Add each `VITE_FIREBASE_*` variable and `VITE_ADMIN_EMAIL` in Site configuration → Environment variables.
5. Deploy. If you later change environment variables, trigger a new deploy.

### Firebase Hosting
```bash
npm install
npm run build
npm install -g firebase-tools
firebase login
firebase init hosting
# Choose existing Firebase project; public directory: dist; configure as single-page app: Yes
firebase deploy
```
If prompted about overwriting `index.html`, keep the Vite-generated file. Re-run `npm run build` before deploying updates.

## Features implemented in this starter

- Email/password account registration and login (Firebase Auth)
- Shared feed using Firestore posts
- Post creation with department and category
- Anonymous display name option (not invisible to moderators/authorized database access)
- Reactions stored in a per-user likes subcollection
- Comments stored in Firestore
- Recent/trending sorting and department/category search filters
- Saved posts (currently saved locally in the current browser; sign-in sync is a future enhancement)
- Lost & found and marketplace feeds using post categories
- Basic admin remove-post UI and starter Firestore rules
- Responsive desktop/mobile layout

## Before inviting students

- **Private messaging is not yet implemented**. Build and test authenticated conversations, participant-only rules, and message reporting before enabling it.
- Replace the sample report toast with a real `/reports` document write and an admin review queue.
- Add rate limiting / abuse prevention (for example App Check, Cloud Functions, and/or a moderation service).
- Set clear community rules, privacy notice, age-appropriate safeguards, and a process for removing harassment, doxxing, scams, and false campus announcements.
- Test Firestore rules with the Firebase Emulator Suite before production.
- If marketplace posts involve sales, encourage safe public handovers; do not collect payment details or student identity documents in posts.
- The anonymous option hides the public display name only. It does not make the account untraceable to trusted administrators or Firebase.
- Use HTTPS hosting and never commit `.env` to a public repository.

## Suggested collections

- `users/{uid}` — display name, email, department, role
- `posts/{postId}` — body, category, department, uid, anonymous, createdAt, likeCount, commentCount, status
- `posts/{postId}/likes/{uid}` — per-user reaction
- `posts/{postId}/comments/{commentId}` — comment text and author
- `reports/{reportId}` — report details and review status
- `messages/{threadId}/items/{messageId}` — future private messaging

## Troubleshooting

- `Couldn't load posts`: verify Firebase project ID and Firestore rules, and ensure Firestore is created.
- `auth/operation-not-allowed`: enable Email/Password in Firebase Authentication.
- New users can sign up but can't post: inspect the Firestore rules and browser console.
- After editing `.env`, stop and restart `npm run dev`.
